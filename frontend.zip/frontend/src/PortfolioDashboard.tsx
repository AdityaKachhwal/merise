import { ChangeEvent, useEffect, useMemo, useState } from 'react'

const API = 'http://localhost:8083/api'
const STORAGE_KEY = 'minevest.portfolio.v1'

type Holding = {
  id: string
  symbol: string
  quantity: number
  averagePrice: number
  currentPrice?: number
  updatedAt?: string
}


type Review = {
  summary?: string
  holdings?: Array<{
    symbol: string
    businessOverview?: string
    businessQuality?: string
    growthDrivers?: string[]
    valuationView?: string
    fundamentalDataStatus?: string
    stockOutlook?: string
    action: 'HOLD' | 'REVIEW' | 'EXIT' | string
    confidence?: string
    reasoning?: string
    risks?: string[]
    dataGaps?: string[]
    holdingAnalysis?: string
  }>
  portfolioRisks?: string[]
  alternatives?: Array<{ symbol: string; rationale: string }>
  disclaimer?: string
}

const money = (value: number) =>
  `₹${Number(value || 0).toLocaleString('en-IN', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  })}`

const pct = (value: number) => `${value >= 0 ? '+' : ''}${value.toFixed(2)}%`

function parseCsvLine(line: string): string[] {
  const cells: string[] = []
  let cell = ''
  let quoted = false

  for (let i = 0; i < line.length; i++) {
    const char = line[i]
    if (char === '"' && line[i + 1] === '"' && quoted) {
      cell += '"'
      i++
    } else if (char === '"') {
      quoted = !quoted
    } else if (char === ',' && !quoted) {
      cells.push(cell.trim())
      cell = ''
    } else {
      cell += char
    }
  }

  cells.push(cell.trim())
  return cells
}

function normalizeHeader(value: string): string {
  return value.toLowerCase().replace(/[^a-z0-9]/g, '')
}

function findColumn(headers: string[], candidates: string[]): number {
  return headers.findIndex(header => candidates.includes(normalizeHeader(header)))
}

function parsePortfolioCsv(text: string): Holding[] {
  const lines = text.replace(/^\uFEFF/, '').split(/\r?\n/).filter(line => line.trim())
  if (lines.length < 2) throw new Error('The CSV does not contain any holdings.')

  const headers = parseCsvLine(lines[0])
  const symbolCol = findColumn(headers, ['symbol', 'tradingsymbol', 'stock', 'ticker', 'scrip'])
  const quantityCol = findColumn(headers, ['quantity', 'qty', 'netquantity', 'shares', 'holdingsquantity'])
  const averageCol = findColumn(headers, [
    'averageprice', 'avgprice', 'buyaverageprice', 'averagecost', 'costprice',
    'purchaseprice', 'avgcost', 'buyprice',
  ])

  if (symbolCol < 0 || quantityCol < 0 || averageCol < 0) {
    throw new Error('Required columns not found. CSV must contain Symbol, Quantity and Average Price.')
  }

  const rows = lines.slice(1).map((line, index) => {
    const cells = parseCsvLine(line)
    const symbol = (cells[symbolCol] || '').trim().toUpperCase().replace(/\.NS$/, '')
    const quantity = Number((cells[quantityCol] || '').replace(/,/g, ''))
    const averagePrice = Number((cells[averageCol] || '').replace(/[₹,]/g, ''))

    if (!symbol || !Number.isFinite(quantity) || quantity <= 0 ||
        !Number.isFinite(averagePrice) || averagePrice <= 0) return null

    return {
      id: `${symbol}-${Date.now()}-${index}`,
      symbol,
      quantity,
      averagePrice,
    } satisfies Holding
  }).filter((item): item is Holding => item !== null)

  if (!rows.length) throw new Error('No valid holdings found in this CSV.')
  return rows
}

async function fetchLatestPrice(symbol: string): Promise<number | undefined> {
  try {
    const response = await fetch(
      `${API}/market-data/prices?symbol=${encodeURIComponent(symbol)}`
    )
    if (!response.ok) return undefined
    const prices = await response.json()
    if (!Array.isArray(prices) || !prices.length) return undefined
    const sortedPrices = [...prices].sort((a, b) =>
        String(a.tradingDate).localeCompare(String(b.tradingDate))
    )
    const latest = sortedPrices[sortedPrices.length - 1]
    const value = Number(latest?.close)
    return Number.isFinite(value) && value > 0 ? value : undefined
  } catch {
    return undefined
  }
}

export default function PortfolioDashboard() {
  const [holdings, setHoldings] = useState<Holding[]>([])
  const [loaded, setLoaded] = useState(false)
  const [busy, setBusy] = useState(false)
  const [message, setMessage] = useState('')
  const [symbol, setSymbol] = useState('')
  const [quantity, setQuantity] = useState('')
  const [averagePrice, setAveragePrice] = useState('')
  const [review, setReview] = useState<Review | null>(null)
  const [reviewBusy, setReviewBusy] = useState(false)

  useEffect(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY)
      if (saved) setHoldings(JSON.parse(saved) as Holding[])
    } catch {
      setMessage('Could not read the saved portfolio. You can import it again.')
    } finally {
      setLoaded(true)
    }
  }, [])

  useEffect(() => {
    if (loaded) localStorage.setItem(STORAGE_KEY, JSON.stringify(holdings))
  }, [holdings, loaded])

  useEffect(() => {
    if (!loaded || !holdings.length) return
    let cancelled = false

    async function refreshPrices() {
      const updated = await Promise.all(holdings.map(async holding => ({
        ...holding,
        currentPrice: await fetchLatestPrice(holding.symbol),
        updatedAt: new Date().toISOString(),
      })))
      if (!cancelled) {
        setHoldings(current => current.map(existing =>
          updated.find(item => item.id === existing.id) || existing
        ))
      }
    }

    void refreshPrices()
    return () => { cancelled = true }
  // Refresh only after initial load; avoid repeated calls after every price update.
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [loaded])

  const totals = useMemo(() => holdings.reduce((acc, holding) => {
    const invested = holding.quantity * holding.averagePrice
    const current = holding.quantity * (holding.currentPrice ?? holding.averagePrice)
    return {
      invested: acc.invested + invested,
      current: acc.current + current,
      pricedValue: acc.pricedValue + (holding.currentPrice ? current : 0),
    }
  }, { invested: 0, current: 0, pricedValue: 0 }), [holdings])

  const pnl = totals.current - totals.invested
  const pnlPercent = totals.invested ? (pnl / totals.invested) * 100 : 0

  async function importCsv(event: ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0]
    if (!file) return

    setBusy(true)
    setMessage('')
    setReview(null)

    try {
      const parsed = parsePortfolioCsv(await file.text())
      const priced = await Promise.all(parsed.map(async holding => ({
        ...holding,
        currentPrice: await fetchLatestPrice(holding.symbol),
      })))
      setHoldings(priced)
      setMessage(`Imported ${priced.length} holding(s). ${priced.filter(x => x.currentPrice).length} current prices matched your market data.`)
    } catch (error) {
      setMessage(error instanceof Error ? error.message : 'Portfolio import failed.')
    } finally {
      setBusy(false)
      event.target.value = ''
    }
  }

  function addHolding() {
    const cleanSymbol = symbol.trim().toUpperCase().replace(/\.NS$/, '')
    const qty = Number(quantity)
    const avg = Number(averagePrice)

    if (!cleanSymbol || !Number.isFinite(qty) || qty <= 0 ||
        !Number.isFinite(avg) || avg <= 0) {
      setMessage('Enter a valid stock symbol, quantity and average purchase price.')
      return
    }

    setHoldings(current => {
      const existing = current.find(item => item.symbol === cleanSymbol)
      if (existing) {
        const totalQty = existing.quantity + qty
        const blendedAverage =
          ((existing.quantity * existing.averagePrice) + (qty * avg)) / totalQty
        return current.map(item => item.id === existing.id
          ? { ...item, quantity: totalQty, averagePrice: blendedAverage }
          : item)
      }
      return [...current, {
        id: `${cleanSymbol}-${Date.now()}`,
        symbol: cleanSymbol,
        quantity: qty,
        averagePrice: avg,
      }]
    })

    setSymbol('')
    setQuantity('')
    setAveragePrice('')
    setMessage(`${cleanSymbol} added to your portfolio.`)
    setReview(null)
  }

  function removeHolding(id: string) {
    setHoldings(current => current.filter(item => item.id !== id))
    setReview(null)
  }

  async function runPortfolioReview() {
    if (!holdings.length) {
      setMessage('Import or add at least one holding before running AI analysis.')
      return
    }

    setReviewBusy(true)
    setMessage('')
    setReview(null)

    try {
      const response = await fetch(`${API}/ai/portfolio-review`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          holdings: holdings.map(item => ({
            symbol: item.symbol,
            quantity: item.quantity,
            averagePrice: item.averagePrice,
            currentPrice: item.currentPrice ?? null,
            investedValue: item.quantity * item.averagePrice,
            currentValue: item.currentPrice
              ? item.quantity * item.currentPrice
              : null,
          })),
          objective: 'Maximum returns with willingness to switch holdings',
          horizon: '12-24 months',
        }),
      })

      const result = await response.json()
      if (!response.ok) {
        throw new Error(result.error || 'AI portfolio review is not available yet.')
      }
      setReview(result)
    } catch (error) {
      setMessage(error instanceof Error ? error.message : 'AI review failed.')
    } finally {
      setReviewBusy(false)
    }
  }

  const styles = {
    panel: {
      background: 'var(--panel, #fff)',
      border: '1px solid var(--border, #e5e7eb)',
      borderRadius: 14,
      padding: 20,
      marginBottom: 18,
    } as const,
    button: {
      border: 0, borderRadius: 9, padding: '10px 14px',
      background: 'var(--accent, #315efb)', color: '#fff',
      fontWeight: 700, cursor: 'pointer',
    } as const,
    input: {
      width: '100%', minWidth: 0, padding: '10px 11px',
      border: '1px solid var(--border, #d8dce5)', borderRadius: 8,
      background: 'var(--surface, #fff)', color: 'inherit',
      boxSizing: 'border-box' as const,
    },
  }

  return (
    <section style={{ marginTop: 24 }}>
      <div style={styles.panel}>
        <div style={{ display: 'flex', justifyContent: 'space-between', gap: 12, flexWrap: 'wrap', alignItems: 'center' }}>
          <div>
            <h2 style={{ margin: 0 }}>My Portfolio</h2>
            <p style={{ margin: '6px 0 0', color: 'var(--muted, #7b8494)', fontSize: 13 }}>
              Import your holdings and see whether each stock still deserves your capital.
            </p>
          </div>
          <label style={{ ...styles.button, display: 'inline-flex', alignItems: 'center', gap: 8 }}>
            {busy ? 'Importing…' : '↑ Import portfolio CSV'}
            <input
              type="file"
              accept=".csv,text/csv"
              disabled={busy}
              onChange={importCsv}
              style={{ display: 'none' }}
            />
          </label>
        </div>

        {message && (
          <div role="status" style={{
            marginTop: 14, padding: 11, borderRadius: 8,
            background: 'var(--surface-soft, #f3f5fa)', fontSize: 13,
          }}>{message}</div>
        )}

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(155px, 1fr))', gap: 10, marginTop: 18 }}>
          {[
            ['Invested value', money(totals.invested)],
            ['Current value', money(totals.current)],
            ['Unrealised P&L', `${pnl >= 0 ? '+' : ''}${money(pnl)}`],
            ['Return', pct(pnlPercent)],
          ].map(([label, value], index) => (
            <div key={label} style={{ padding: 14, borderRadius: 10, background: 'var(--surface-soft, #f4f6fa)' }}>
              <div style={{ color: 'var(--muted, #7b8494)', fontSize: 12 }}>{label}</div>
              <strong style={{
                display: 'block', marginTop: 7, fontSize: 19,
                color: index >= 2 ? (pnl >= 0 ? '#168653' : '#d04444') : 'inherit',
              }}>{value}</strong>
            </div>
          ))}
        </div>
        {holdings.length > 0 && totals.pricedValue < totals.current && (
          <p style={{ color: 'var(--muted, #7b8494)', fontSize: 12, marginBottom: 0 }}>
            Some holdings have no matching imported market price. Their current value is temporarily shown at average cost.
          </p>
        )}
      </div>

      <div style={styles.panel}>
        <h3 style={{ marginTop: 0 }}>Add holding manually</h3>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(130px, 1fr))', gap: 10 }}>
          <input style={styles.input} placeholder="Symbol e.g. CDSL" value={symbol} onChange={e => setSymbol(e.target.value)} />
          <input style={styles.input} type="number" min="0" placeholder="Quantity" value={quantity} onChange={e => setQuantity(e.target.value)} />
          <input style={styles.input} type="number" min="0" step="0.01" placeholder="Average price ₹" value={averagePrice} onChange={e => setAveragePrice(e.target.value)} />
          <button style={styles.button} onClick={addHolding}>Add stock</button>
        </div>
      </div>

      <div style={styles.panel}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 12, flexWrap: 'wrap' }}>
          <h3 style={{ margin: 0 }}>Your holdings ({holdings.length})</h3>
          <button style={styles.button} disabled={reviewBusy || !holdings.length} onClick={runPortfolioReview}>
            {reviewBusy ? 'Analysing stocks…' : '✦ Run AI stock assessment'}
          </button>
        </div>

        {!holdings.length ? (
          <div style={{ padding: '28px 10px', textAlign: 'center', color: 'var(--muted, #7b8494)' }}>
            No holdings yet. Import a broker CSV or add your first stock manually.
          </div>
        ) : (
          <div style={{ overflowX: 'auto', marginTop: 14 }}>
            <table style={{ width: '100%', borderCollapse: 'collapse', minWidth: 690, textAlign: 'left' }}>
              <thead>
                <tr>{['Stock', 'Qty', 'Avg. price', 'Current price', 'Invested', 'P&L', ''].map(label => (
                  <th key={label} style={{ padding: 11, fontSize: 12, color: 'var(--muted, #7b8494)', borderBottom: '1px solid var(--border, #e5e7eb)' }}>{label}</th>
                ))}</tr>
              </thead>
              <tbody>
                {holdings.map(item => {
                  const invested = item.quantity * item.averagePrice
                  const current = item.quantity * (item.currentPrice ?? item.averagePrice)
                  const gain = current - invested
                  return (
                    <tr key={item.id}>
                      <td style={{ padding: 12, borderBottom: '1px solid var(--border, #e5e7eb)', fontWeight: 700 }}>{item.symbol}</td>
                      <td style={{ padding: 12, borderBottom: '1px solid var(--border, #e5e7eb)' }}>{item.quantity}</td>
                      <td style={{ padding: 12, borderBottom: '1px solid var(--border, #e5e7eb)' }}>{money(item.averagePrice)}</td>
                      <td style={{ padding: 12, borderBottom: '1px solid var(--border, #e5e7eb)' }}>{item.currentPrice ? money(item.currentPrice) : 'Price unavailable'}</td>
                      <td style={{ padding: 12, borderBottom: '1px solid var(--border, #e5e7eb)' }}>{money(invested)}</td>
                      <td style={{ padding: 12, borderBottom: '1px solid var(--border, #e5e7eb)', color: gain >= 0 ? '#168653' : '#d04444', fontWeight: 700 }}>
                        {gain >= 0 ? '+' : ''}{money(gain)}
                      </td>
                      <td style={{ padding: 12, borderBottom: '1px solid var(--border, #e5e7eb)' }}>
                        <button onClick={() => removeHolding(item.id)} aria-label={`Remove ${item.symbol}`} style={{ border: 0, background: 'transparent', color: '#d04444', cursor: 'pointer' }}>Remove</button>
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>


      {review && (
          <div style={styles.panel}>
            <h3 style={{ marginTop: 0 }}>AI Stock Intelligence</h3>

            <p style={{ color: 'var(--muted, #7b8494)', fontSize: 13 }}>
              Each company is assessed independently of your portfolio allocation.
            </p>

            {review.summary && (
                <p style={{ lineHeight: 1.65 }}>{review.summary}</p>
            )}

            {review.holdings?.map(item => (
                <div
                    key={item.symbol}
                    style={{
                      padding: '18px 0',
                      borderTop: '1px solid var(--border, #e5e7eb)',
                    }}
                >
                  <div style={{
                    display: 'flex',
                    gap: 10,
                    alignItems: 'center',
                    flexWrap: 'wrap',
                  }}>
                    <h3 style={{ margin: 0 }}>{item.symbol}</h3>
                    <span style={{
                      padding: '5px 9px',
                      borderRadius: 6,
                      background: 'var(--surface-soft, #f1f4fa)',
                      fontSize: 12,
                      fontWeight: 700,
                    }}>
            {item.stockOutlook || 'OUTLOOK UNAVAILABLE'}
          </span>
                    <strong>{item.action}</strong>
                    {item.confidence && (
                        <small>Confidence: {item.confidence}</small>
                    )}
                  </div>

                  {item.businessOverview && (
                      <>
                        <h4>Business overview</h4>
                        <p>{item.businessOverview}</p>
                      </>
                  )}

                  {item.businessQuality && (
                      <>
                        <h4>Business quality and competitive position</h4>
                        <p>{item.businessQuality}</p>
                      </>
                  )}

                  {item.growthDrivers?.length ? (
                      <>
                        <h4>Growth drivers</h4>
                        <ul>
                          {item.growthDrivers.map((x, i) => (
                              <li key={i}>{x}</li>
                          ))}
                        </ul>
                      </>
                  ) : null}

                  {item.valuationView && (
                      <>
                        <h4>Valuation</h4>
                        <p>{item.valuationView}</p>
                      </>
                  )}

                  {item.reasoning && (
                      <>
                        <h4>Investment outlook</h4>
                        <p style={{ lineHeight: 1.6 }}>{item.reasoning}</p>
                      </>
                  )}

                  {item.holdingAnalysis && (
                      <>
                        <h4>Your holding</h4>
                        <p>{item.holdingAnalysis}</p>
                      </>
                  )}

                  {item.risks?.length ? (
                      <>
                        <h4>Business and investment risks</h4>
                        <ul>
                          {item.risks.map((risk, i) => (
                              <li key={i}>{risk}</li>
                          ))}
                        </ul>
                      </>
                  ) : null}

                  {item.dataGaps?.length ? (
                      <>
                        <h4>Data still required</h4>
                        <ul>
                          {item.dataGaps.map((gap, i) => (
                              <li key={i}>{gap}</li>
                          ))}
                        </ul>
                      </>
                  ) : null}

                  <small style={{ color: 'var(--muted, #7b8494)' }}>
                    Fundamental data status: {item.fundamentalDataStatus || 'Not verified'}
                  </small>
                </div>
            ))}

            <p style={{
              color: 'var(--muted, #7b8494)',
              fontSize: 12,
            }}>
              {review.disclaimer || 'AI research is not a guaranteed forecast or an instruction to trade.'}
            </p>
          </div>
      )}


      <p style={{ color: 'var(--muted, #7b8494)', fontSize: 12 }}>
        CSV import currently expects Symbol, Quantity and Average Price columns. Holdings are stored in this browser. Live prices require the symbol to exist in MineVest's imported NSE data. Excel and CAS parsing can be added after validating the source formats.
      </p>
    </section>
  )
}
