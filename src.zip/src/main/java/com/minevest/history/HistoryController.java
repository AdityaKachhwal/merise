package com.minevest.history;

import com.fasterxml.jackson.core.type.TypeReference;
import com.minevest.marketdata.NseHistoricalDataService;
import com.minevest.marketdata.NseSyncResult;
import com.minevest.storage.JsonFileStore;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/api")
public class HistoryController {
    private final JsonFileStore store;
    private final MarketAnalysisService analysis;
    private final NseHistoricalDataService nseData;

    public HistoryController(JsonFileStore store, MarketAnalysisService analysis,
                             NseHistoricalDataService nseData) {
        this.store = store;
        this.analysis = analysis;
        this.nseData = nseData;
    }

    @PostMapping("/analysis/run")
    public AnalysisSnapshot run() throws Exception {
        NseSyncResult sync = null;
        String syncNote;
        try {
            sync = nseData.syncRecentSessions();
            syncNote = sync.message() + " New rows added: " + sync.rowsAdded()
                    + "; archives downloaded: " + sync.archivesDownloaded() + ".";
        } catch (Exception ex) {
            syncNote = "NSE update could not be completed (" + safeMessage(ex)
                    + "). Analysis continued using the locally stored market data.";
        }

        AnalysisSnapshot calculated = analysis.run();
        AnalysisSnapshot snapshot = new AnalysisSnapshot(
                calculated.runId(), calculated.createdAt(), calculated.status(),
                calculated.importedPriceRows(), calculated.distinctSymbols(),
                calculated.note() + " NSE data update: " + syncNote,
                calculated.recommendations());

        List<AnalysisSnapshot> all = store.readJsonList(
                "history.json", new TypeReference<List<AnalysisSnapshot>>() {});
        all = new ArrayList<>(all);
        all.add(0, snapshot);
        store.writeJson("history.json", all);
        return snapshot;
    }

    /** Diagnostic endpoint: runs only the incremental NSE sync, without stock analysis. */
    @PostMapping("/market-data/sync")
    public NseSyncResult syncMarketData() throws Exception {
        return nseData.syncRecentSessions();
    }

    @GetMapping("/history")
    public List<AnalysisSnapshot> history() throws Exception {
        return store.readJsonList("history.json", new TypeReference<List<AnalysisSnapshot>>() {});
    }

    @GetMapping("/history/{runId}")
    public AnalysisSnapshot get(@PathVariable String runId) throws Exception {
        return history().stream().filter(s -> s.runId().equals(runId)).findFirst()
                .orElseThrow(() -> new IllegalArgumentException("Analysis run not found: " + runId));
    }

    private static String safeMessage(Exception ex) {
        return ex.getMessage() == null || ex.getMessage().isBlank()
                ? ex.getClass().getSimpleName() : ex.getMessage();
    }
}
