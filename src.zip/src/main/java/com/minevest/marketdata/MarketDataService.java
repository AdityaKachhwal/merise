package com.minevest.marketdata;

import com.minevest.storage.JsonFileStore;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

@Service
public class MarketDataService {
    private final JsonFileStore store;

    public MarketDataService(JsonFileStore store) { this.store = store; }

    public ImportResult importFile(MultipartFile file) throws Exception {
        byte[] bytes = file.getBytes();
        String name = file.getOriginalFilename() == null ? "upload" : file.getOriginalFilename();
        InputStream csvStream;
        if (name.toLowerCase(Locale.ROOT).endsWith(".zip")) {
            ZipInputStream zip = new ZipInputStream(new ByteArrayInputStream(bytes));
            ZipEntry entry;
            csvStream = null;
            while ((entry = zip.getNextEntry()) != null) {
                if (!entry.isDirectory() && entry.getName().toLowerCase(Locale.ROOT).endsWith(".csv")) {
                    csvStream = zip;
                    break;
                }
            }
            if (csvStream == null) throw new IllegalArgumentException("ZIP archive does not contain a CSV file");
            List<DailyPrice> rows = CsvRowParser.parse(new InputStreamReader(csvStream, StandardCharsets.UTF_8));
            int added = store.savePrices(rows);
            return new ImportResult(name, rows.size(), added, 0,
                    "Imported and merged rows. Duplicate date/symbol/series/ISIN records are not added twice.");
        }
        if (!name.toLowerCase(Locale.ROOT).endsWith(".csv")) {
            throw new IllegalArgumentException("Please upload an NSE .zip archive or .csv file");
        }
        List<DailyPrice> rows = CsvRowParser.parse(new InputStreamReader(new ByteArrayInputStream(bytes), StandardCharsets.UTF_8));
        int added = store.savePrices(rows);
        return new ImportResult(name, rows.size(), added, 0,
                "Imported and merged rows. Duplicate date/symbol/series/ISIN records are not added twice.");
    }

    public List<DailyPrice> prices(String symbol) throws Exception {
        return store.readPrices().stream()
                .filter(p -> p.symbol().equalsIgnoreCase(symbol))
                .sorted(Comparator.comparing(DailyPrice::tradingDate))
                .toList();
    }

    public List<String> symbols() throws Exception {
        return store.readPrices().stream().map(DailyPrice::symbol).distinct().sorted().toList();
    }

    public List<DailyPrice> allPrices() throws Exception { return store.readPrices(); }

    public int totalRows() throws Exception { return store.readPrices().size(); }
}
