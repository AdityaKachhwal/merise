package com.minevest.marketdata;

import org.springframework.data.jpa.repository.JpaRepository;
import java.time.LocalDate;
import java.util.List;

public interface DailyPriceRepository
        extends JpaRepository<DailyPriceEntity, Long> {

    boolean existsByTradingDateAndSymbolAndSeriesAndIsin(
            LocalDate tradingDate, String symbol, String series, String isin);

    List<DailyPriceEntity> findBySymbolIgnoreCaseOrderByTradingDateAsc(String symbol);

    List<DailyPriceEntity> findAllByOrderByTradingDateAsc();

    List<DailyPriceEntity> findAllByOrderByTradingDateDesc();

    List<DailyPriceEntity> findByTradingDateBetween(LocalDate from, LocalDate to);

    long countByTradingDate(LocalDate date);
}
