
package com.minevest.ai;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;
import org.springframework.web.client.RestClientResponseException;
import org.springframework.web.server.ResponseStatusException;

import java.time.Duration;
import java.util.List;
import java.util.Map;

@Service
public class GeminiAiService {

    private static final Logger log =
            LoggerFactory.getLogger(GeminiAiService.class);

    private final ObjectMapper objectMapper;
    private final RestClient restClient;

    @Value("${gemini.api.key:}")
    private String apiKey;

    @Value("${gemini.model:gemini-3.5-flash}")
    private String model;

    public GeminiAiService(ObjectMapper objectMapper) {
        this.objectMapper = objectMapper;

        SimpleClientHttpRequestFactory factory =
                new SimpleClientHttpRequestFactory();

        factory.setConnectTimeout(Duration.ofSeconds(10));
        factory.setReadTimeout(Duration.ofSeconds(60));

        this.restClient = RestClient.builder()
                .requestFactory(factory)
                .build();
    }

    public JsonNode reviewPortfolio(JsonNode portfolio) {

        if (apiKey == null || apiKey.isBlank()) {
            throw new ResponseStatusException(
                    HttpStatus.SERVICE_UNAVAILABLE,
                    "Gemini API key is not configured."
            );
        }

        try {
            log.info("Starting individual stock intelligence assessment");

            String prompt = """
                    You are an independent Indian equity research analyst.

                    TASK:
                    Assess EVERY stock in the supplied holdings array as an
                    INDEPENDENT COMPANY AND INVESTMENT OPPORTUNITY.

                    THIS IS NOT A PORTFOLIO ALLOCATION REVIEW.

                    STRICT RULES:
                    1. Never assess a company based on its percentage of the
                       user's portfolio.
                    2. Never recommend REVIEW merely because the user owns
                       only one stock.
                    3. Do not discuss diversification or concentration.
                    4. Assess each company independently.
                    5. Explain its business model, competitive position,
                       industry, growth drivers and business risks.
                    6. Use general knowledge only for stable background facts.
                       Clearly identify information that needs verification.
                    7. Do not invent current revenue, profit, margins, debt,
                       P/E, P/B, cash flow or other financial metrics.
                    8. No live financial statements, announcements or news
                       have been supplied. Do not claim to have checked them.
                    9. If valuation cannot be verified, explicitly say so.
                    10. Separate company quality from the user's personal
                        holding performance.
                    11. The purchase price must not determine whether a
                        company is fundamentally good or bad.
                    12. Do not promise returns or invent alternative stocks.

                    For each stock, provide:

                    - Business overview
                    - Business quality and competitive position
                    - Potential growth drivers
                    - Valuation assessment, if data is available
                    - Important business and investment risks
                    - Missing information needed for a reliable assessment
                    - An independent stock outlook
                    - A separate holding decision using the user's
                      purchase price, current price and stated horizon

                    If fundamental data is unavailable, do not pretend to
                    produce a complete fundamental rating. Clearly state
                    that the assessment is preliminary.

                    Return ONLY valid JSON in this structure:

                    {
                      "summary": "Short overview of the individual stocks assessed",
                      "holdings": [
                        {
                          "symbol": "CDSL",
                          "businessOverview": "What the company does",
                          "businessQuality": "Business quality and competitive position",
                          "growthDrivers": ["Potential growth driver"],
                          "valuationView": "Valuation assessment or unavailable",
                          "fundamentalDataStatus": "NOT_CONNECTED",
                          "stockOutlook": "POSITIVE, NEUTRAL, NEGATIVE or INSUFFICIENT_DATA",
                          "action": "HOLD, REVIEW or EXIT",
                          "confidence": "Low, Medium or High",
                          "reasoning": "Explain the independent stock view",
                          "risks": ["Important business risk"],
                          "dataGaps": ["Financial information that must be obtained"],
                          "holdingAnalysis": "Separate assessment of the user's position"
                        }
                      ],
                      "portfolioRisks": [],
                      "alternatives": [],
                      "disclaimer": "Preliminary AI research. Verify financial data before investing."
                    }

                    Allowed actions: HOLD, REVIEW, EXIT.

                    If there is insufficient evidence for a reliable
                    investment decision, use REVIEW and Low confidence.
                    Do not confuse missing data with a poor company.

                    Investor objective:
                    Maximum returns, willing to switch holdings.

                    Investment horizon:
                    12-24 months.

                    Input data:
                    """ + portfolio.toPrettyString();

            Map<String, Object> request = Map.of(
                    "contents", List.of(
                            Map.of(
                                    "parts", List.of(
                                            Map.of("text", prompt)
                                    )
                            )
                    ),
                    "generationConfig", Map.of(
                            "temperature", 0.2,
                            "responseMimeType", "application/json"
                    )
            );

            JsonNode response = callGeminiWithRetry(request);

            JsonNode textNode = response == null
                    ? null
                    : response.path("candidates")
                      .path(0)
                      .path("content")
                      .path("parts")
                      .path(0)
                      .path("text");

            if (textNode == null || textNode.isMissingNode()
                    || textNode.asText().isBlank()) {
                throw new ResponseStatusException(
                        HttpStatus.BAD_GATEWAY,
                        "Gemini returned an empty response."
                );
            }

            JsonNode result = objectMapper.readTree(textNode.asText());

            log.info("Individual stock assessment completed");

            return result;

        } catch (RestClientResponseException ex) {
            log.error("Gemini API returned HTTP {}: {}",
                    ex.getStatusCode().value(),
                    ex.getResponseBodyAsString());

            throw new ResponseStatusException(
                    HttpStatus.BAD_GATEWAY,
                    "Gemini API error: " + ex.getStatusCode().value()
            );

        } catch (ResponseStatusException ex) {
            throw ex;

        } catch (Exception ex) {
            log.error("Stock assessment failed", ex);

            throw new ResponseStatusException(
                    HttpStatus.BAD_GATEWAY,
                    "Unable to complete stock assessment."
            );
        }
    }

    private JsonNode callGeminiWithRetry(Map<String, Object> request) {

        int maxAttempts = 3;

        for (int attempt = 1; attempt <= maxAttempts; attempt++) {
            try {
                return restClient.post()
                        .uri("https://generativelanguage.googleapis.com/v1beta/models/"
                                + model + ":generateContent")
                        .header("x-goog-api-key", apiKey)
                        .contentType(MediaType.APPLICATION_JSON)
                        .body(request)
                        .retrieve()
                        .body(JsonNode.class);

            } catch (RestClientResponseException ex) {

                int status = ex.getStatusCode().value();

                boolean temporaryError =
                        status == 429 ||
                                status == 500 ||
                                status == 502 ||
                                status == 503 ||
                                status == 504;

                if (!temporaryError || attempt == maxAttempts) {
                    throw ex;
                }

                long delayMillis = attempt * 1000L;

                log.warn(
                        "Gemini temporarily unavailable (HTTP {}). "
                                + "Retrying attempt {}/{} after {} ms",
                        status, attempt + 1, maxAttempts, delayMillis
                );

                try {
                    Thread.sleep(delayMillis);
                } catch (InterruptedException interrupted) {
                    Thread.currentThread().interrupt();
                    throw new ResponseStatusException(
                            HttpStatus.SERVICE_UNAVAILABLE,
                            "Gemini retry interrupted."
                    );
                }
            }
        }

        throw new ResponseStatusException(
                HttpStatus.BAD_GATEWAY,
                "Gemini request failed after retries."
        );
    }
}
